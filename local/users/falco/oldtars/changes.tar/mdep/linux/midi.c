/*
 *	Copyright 1996 AT&T Corp.  All rights reserved.
 */

/*
 * This contains support for Voxware MIDI version 2.9 and (hopefully) later.
 * It assumes Voxware is installed.
 */

#include "key.h"
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/* Change this if you prefer to use a different default MIDI interface */
#define MIDIDEVICE "/dev/midi00"

extern int errno;

int
mdep_initmidi(void)
{
	extern char **Devmidi;
	int r;
	int ret = 0;
	char *MidiDevice;

	if ( (MidiDevice = getenv("MIDIDEVICE")) == NULL ) {
		MidiDevice = MIDIDEVICE;
	}

	Midifd = open(MidiDevice,O_RDWR);
	if ( Midifd >= 0 ) {

		if ( Devmidi )
			*Devmidi = uniqstr(MidiDevice);
		if ( ! ismuxable(Midifd) ) {
			fprintf(stderr,"Hey, Midifd isn't muxable!\n");
			exit(1);
		}
	}
	else {
		fprintf(stderr,"Unable to open %s (errno=%d)\n",
			MidiDevice,errno);
		ret = 1;
	}
	return(ret);
}

void
mdep_endmidi(void)
{
	if ( Midifd >= 0 )
		close(Midifd);
}

/* must return -1 if there is nothing to read */
int
mdep_getnmidi(char *buff,int buffsize)
{
	fd_set readfds;
	fd_set writefds;
	fd_set exceptfds;
	struct timeval t;

	if ( Midifd < 0 )
		return 0;

	FD_ZERO(&readfds);
	FD_ZERO(&writefds);
	FD_ZERO(&exceptfds);
	FD_SET(Midifd, &readfds);
	FD_SET(Midifd, &exceptfds);
	t.tv_sec = 0;
	t.tv_usec = 0;
	if(select(Midifd+1, &readfds, &writefds, &exceptfds, &t) == 0) {
		return -1;
	}
	return read(Midifd, buff, buffsize);
}

void
mdep_putnmidi(int n,char *p)
{
	int i;

	if ( Midifd < 0 )
		return;
	if ( write(Midifd,p,(unsigned)n) != n ) {
		eprint("Hmm, write to MIDI device didn't write everything?\n");
		keyerrfile("Hmm, write to MIDI device didn't write everything?\n");
	}
}
