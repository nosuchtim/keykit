KeyKit 8.8 for Windows (x64)

Extract the entire key folder, then run bin\key.exe.
The console interpreter is bin\lowkey.exe. Run bin\keylib.exe from the lib
folder if you edit the library and need to rebuild its function index.

WinMM is the default MIDI backend. Set KEYKIT_MIDI_API=wms before starting
KeyKit to request Windows MIDI Services. The preview Windows MIDI Services
API runtime is not bundled; see README.windows and rtmidi\README.keykit.md.

The three shared WMS loopbacks appear in KeyKit as KeyKit Loopback 1, 2,
and 3, using the same name for input and output. Other applications see
the native endpoints named KeyKit Loopback N output and KeyKit Loopback N
input: send to output and receive from input.

Microsoft Visual C++ x64 runtime DLLs are included alongside the executables.
Keep these DLLs with the executables when moving the installation.
KeyKit's license is in LICENSE.txt; RtMidi's license is in rtmidi\LICENSE.
Documentation is in doc, library/tools in lib, and sample music in music.