KeyKit 8.8 for Windows (x64)

Extract the entire key folder, then run bin\key.exe. Keep its DLLs alongside it.
The console interpreter is bin\lowkey.exe. To rebuild the library index after
editing it, run bin\keylib.exe with lib as the working directory.

WinMM is the default MIDI backend. Set KEYKIT_MIDI_API=wms before starting
KeyKit to request Windows MIDI Services. See README.windows for details.
Documentation is in doc, library/tools in lib, and sample music in music.
Licenses and WMS preview/runtime information are in LICENSE.txt and rtmidi.

This archive requires Windows 11 25H2 or later. It includes Microsoft's
Windows MIDI Services preview API 0.99.92-preview.11 (DLL and PRI); no SDK
installation is needed. The Windows MIDI service must be present and enabled.
This is a preview API. See rtmidi\WINDOWS-MIDI-SERVICES-RUNTIME.txt.

For older Windows systems, use key88_win_winmm.zip,
which does not contain the preview API binaries.