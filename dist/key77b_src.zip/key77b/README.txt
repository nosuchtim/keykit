KeyKit - Musical Fun with Windows, Tasks, and Objects

by Tim Thompson (tjt@nosuch.com)

See top-level makefile for instructions on compiling.  See the doc directory
for other documentation.  In particular, see doc/porting for details
on the machine-dependent support needed for a given platform.

