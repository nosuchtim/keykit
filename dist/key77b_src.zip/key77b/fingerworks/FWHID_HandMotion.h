/**
 *  @file FWHID_HandMotion.h
 *  FingerWorks HID Hand Motion SDK (External API)
 *
 *  @author Created by Wayne Westerman on Wed Jun 25 2003.
  *  @author Last Updated Wayne Westerman on Wed Dec 8 2003.

  *  v0.65 fixed FWHID_ZoneSpecifier for little endian  
  *  v1.0 changed FWHID_ZoneSpecifier to FWHID_FingerSpecifier, and added handActionCode and handPositionX/Y
  *  v1.53 Added comments for all data structure fields.
  *  Copyright (c) 2003-2004 FingerWorks, Inc. All rights reserved. 
  **/
 /* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is FWHID_HandMotion.h, 
 *   External API for FingerWorks HID Hand Motion SDK.
 *
 * The Initial Developer of the Original Code is
 * Wayne Westerman, FingerWorks, Inc.
 *
 * Portions created by the Initial Developer are Copyright (C) 2003-2004
 * by FingerWorks Inc. All Rights Reserved.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */
 

#ifndef _FWHID_HandMotion_h_
#define _FWHID_HandMotion_h_

#include "FWHID_PlatformDefs.h"

#ifdef __cplusplus
extern "C" {
#endif
    
/** "Any fingertip permutation" chords.
    These are the chords currently defined in the MyGesture Editor libraries.

    Thumb presence, fingertip count, and neutral/spread finger arrangement 
    are recognized reliably from informed operators
    but actual permutation of palms and starting fingertips may vary.
    
    See FWHID_ZoneSpecifier for ongoing finger identity estimates
Key:
   T = thumb
   #F = fingertip count
   S = spread (not neutral) hand arrangement
*/
#define kFWHID_Chord_1F 0x1004
#define kFWHID_Chord_2F 0x100C
#define kFWHID_Chord_2FS 0x1812
#define kFWHID_Chord_3F 0x100E
#define kFWHID_Chord_3FS 0x181C
#define kFWHID_Chord_4F 0x101E
#define kFWHID_Chord_4FS 0x181E
#define kFWHID_Chord_T1F 0x1005
#define kFWHID_Chord_T1FS 0x1805
#define kFWHID_Chord_T2F 0x1007
#define kFWHID_Chord_T2FS 0x1819
#define kFWHID_Chord_TIPS 0x1813
#define kFWHID_Chord_T3F 0x100F
#define kFWHID_Chord_T3FS 0x181D
#define kFWHID_Chord_T4F 0x101F
#define kFWHID_Chord_T4FS 0x181F
#define kFWHID_Chord_PenGrip 0x1100
#define kFWHID_Chord_TriPenGrip 0x1200
#define kFWHID_Chord_FistPalms 0x1400

#define kFWHID_RightHandMask 0x8000
#define kFWHID_LeftHandMask 0x4000
#define kFWHID_BimanualSyncMask 0x2000
#define kFWHID_AnyFingertipPermutationMask 0x1000

#define kFWHID_ActionCode_WinMinCode 0x80
#define kFWHID_ActionCode_WinHide 0x81
#define kFWHID_ActionCode_WinSendToBottom 0x82
#define kFWHID_ActionCode_WinBringToTop 0x83
#define kFWHID_ActionCode_WinMinimize 0x84
#define kFWHID_ActionCode_WinRestore 0x85
#define kFWHID_ActionCode_WinToggle 0x86
#define kFWHID_ActionCode_WinMaximize 0x87

#define kFWHID_ActionCode_SubWinSendToBottom 0x92
#define kFWHID_ActionCode_SubWinSendToTop 0x93
#define kFWHID_ActionCode_SubWinMinimize 0x94
#define kFWHID_ActionCode_SubWinRestore 0x95
#define kFWHID_ActionCode_SubWinToggle 0x96
#define kFWHID_ActionCode_SubWinMaximize 0x97
#define kFWHID_ActionCode_SubWinMaxCode 0x9F
//create new Carbon event class 'hand'?
enum {
    kEventClassHand = 'hand'
};

//'hand' event class sub-types
enum {
    kEventHandNoChange = 0,
    kEventHandChordSelected = 1, //should not include any motion
    kEventHandChordReleased = 2, //should not include any motion
	kEventHandCommand = 4,
    kEventHandPressure = 8,
    kEventHandTranslate = 9,
    kEventHandRotate = 10,
    kEventHandTranslateRotate = 11,
    kEventHandScale = 12,
    kEventHandTranslateScale = 13,
    kEventHandRotateScale = 14,
    kEventHandMotion = 15, //any/all of translation/rotation/scaling!
    kEventHandIDmax
};

/** FingerWorks products allow chord selection, i.e. update the FWHID_ChordSpecifier,
   only at initial hand touchdown. Further changes in finger presence after initial
   touchdown are ignored for chord selection purposes until the whole hand lifts. 
   @brief Bit fields storing the identified finger combination, special finger arrangements, and source hand. */   
#ifdef __BIG_ENDIAN__
typedef union {
    unsigned short word;
    struct {
        //PowerPC & Sun compilers put bit 15 at top of bitfield, bit 0 at bottom!
        unsigned int lefthand : 1;  /** <@brief If true indicates source of this motion is left hand. */		
        unsigned int righthand : 1; /** <@brief If true indicates source of this motion is right hand. */		
        unsigned int bimanualSync : 1; /** <@brief If true indicates both hands started working together (touched with the same chord at same time). */
		/** @brief If true, the index/middle/ring/pinky bit range holds a fingertip count rather than bit pattern marking exactly which of index/middle/ring/pinky are present. */
        unsigned int anyFingertipPermutation : 1;
		/** Indicates fingers were spread rather than neutral upon chord touchdown. */
        unsigned int spread : 1;
		/** If true, the special "fist" or "5 knuckles" hand configuration has been detected. */
        unsigned int fist : 1;
		/** If true, the special "triPenGrip" hand configuration (thumb, index fingertip, middle fingertip, ring knuckle and pinky knuckle) has been detected. */
        unsigned int triPenGrip : 1;
		/** If true, the special "penGrip" hand configuration (thumb, index fingertip, middle knuckle, ring knuckle and pinky knuckle) has been detected. */
        unsigned int penGrip : 1;
		unsigned int forePalms : 1; /** <@brief Indicates that hand is totally flattened such that central palm & callouses are touching. */
        unsigned int innerPalm : 1; /**  <@brief Indicates that inner palm heel (closest to thumb) is touching. */
        unsigned int outerPalm : 1; /**  <@brief Indicates that outer palm heel (closest to pinky) is touching. */
        unsigned int pinky : 1; /** <@brief Indicates that pinky finger is touching. */
        unsigned int ring : 1; /** <@brief Indicates that ring finger is touching. */
        unsigned int middle : 1; /** <@brief Indicates that middle finger is touching. */
		/** @brief Indicates that index finger is touching. */
        unsigned int index : 1; 
		/** @brief (Bit0) Indicates that thumb is touching. */
        unsigned int thumb : 1; 
    } flags;
    struct {
        //PowerPC compilers put bit 15 at top of bitfield, bit 0 at bottom!
		/** Three bit field indicating source of hand motion (right or left) and whether hands are synced (started working together) */
        unsigned int hand : 3;
		/** If anyFingertipPermutation bit is set, the index/middle/ring/pinky bit range holds a fingertip count rather than bit pattern marking exactly which of index/middle/ring/pinky are present */
        unsigned int anyFingertipPermutation : 1;
		/** Four-bit field indicating special fingers-curled or knuckle-touching grips. */
        unsigned int grip : 4;
        unsigned int fingers : 8;   
    } fields;
    struct {
        //PowerPC compilers put bit 15 at top of bitfield, bit 0 at bottom!
		/** Three bit field indicating source of hand motion (right or left) and whether hands are synced (started working together) */
        unsigned int hand : 3;
        unsigned int chord : 13;   
    } compare;
} FWHID_ChordSpecifier;

#else //Intel architectures are little Endian

typedef union {
    unsigned short word;
    struct {
        //Intel compilers put bit 0 at top of bitfield, bit 15 at bottom!		
		/** @brief (Bit0) Flag indicating whether thumb is touching. */
        unsigned int thumb : 1; 
		/** @brief Indicates that index finger is touching. */		
        unsigned int index : 1; 
		/** @brief Indicates that middle finger is touching. */		
        unsigned int middle : 1; 
		/** @brief Indicates that ring finger is touching. */		
        unsigned int ring : 1; 
		/** @brief Indicates that pinky finger is touching. */		
        unsigned int pinky : 1; 
		/** @brief Indicates that outer palm heel (closest to pinky) is touching. */
        unsigned int outerPalm : 1; 
		/** @brief Indicates that inner palm heel (closest to thumb) is touching. */		
        unsigned int innerPalm : 1; 
		/** @brief Indicates that hand is totally flattened such that central palm & callouses are touching. */
        unsigned int forePalms : 1; 		
		/** If true, the special "penGrip" hand configuration (thumb, index fingertip, middle knuckle, ring knuckle and pinky knuckle) has been detected. */
        unsigned int penGrip : 1; 
		/** If true, the special "triPenGrip" hand configuration (thumb, index fingertip, middle fingertip, ring knuckle and pinky knuckle) has been detected. */
        unsigned int triPenGrip : 1;
		/** If true, the special "fist" or "5 knuckles" hand configuration has been detected. */
        unsigned int fist : 1;
		/** @brief Indicates fingers were spread rather than neutral upon chord touchdown. */
        unsigned int spread : 1; 
		/** @brief If true, the index/middle/ring/pinky bit range holds a fingertip count rather than bit pattern marking exactly which of index/middle/ring/pinky are present. */
        unsigned int anyFingertipPermutation : 1;
		/** @brief If true indicates both hands started working together (touched with the same chord at same time). */
        unsigned int bimanualSync : 1;		
		/** @brief If true indicates source of this motion is right hand. */		
        unsigned int righthand : 1; 
		/** @brief If true indicates source of this motion is left hand. */
        unsigned int lefthand : 1;  
    } flags;
	/** @brief For comparing finger combination, special grips and hands separately. */
    struct {
        //Intel compilers put bit 0 at top of bitfield, bit 15 at bottom!
        unsigned int fingers : 8;   
		/** Four-bit field indicating special fingers-curled or knuckle-touching grips. */
        unsigned int grip : 4;		
        unsigned int anyFingertipPermutation : 1;
		/** Three bit field indicating source of hand motion (right or left) and whether hands are synced (started working together) */
        unsigned int hand : 3;
    } fields;
	/** @brief For comparing chord/grip and hands separately. */
    struct {
        //Intel compilers put bit 0 at top of bitfield, bit 15 at bottom!
        unsigned int chord : 13;   		
        unsigned int hand : 3;
    } compare;
} FWHID_ChordSpecifier;
#endif //POWERPC

/* (Deprecated) FingerWorks products continually update the FWHID_ZoneSpecifier.
These fields roughly indicate hand position on the surface with
respect to 2cm zones around home row.  A hand within +-1cm of home
row (or surface center) is in zone 0.  Above home row (+1 to +3cm)
is vertical zone 1, below home row (-1 to -3cm) is vertical zone -1,
and so on for zones -7 thru +7, horizontal and vertical.  */

/**FWHID_FingerSpecifier includes continuosly updated estimates
of which fingers are actively touching the surface. These are
estimates, not guaranteed to be accurate, but thumb presence,
palm presence, and fingertip count are pretty reliable.  

@brief Bit field structure for storing which fingers/palms are currently touching. */   

#ifdef __BIG_ENDIAN__
typedef union {
    unsigned short word;
    struct {
        //PowerPC compilers put bit 15 at top of bitfield, bit 0 at bottom!
		unsigned int reserved : 8;
        unsigned int forePalms : 1;
        unsigned int innerPalm : 1;
        unsigned int outerPalm : 1;
        unsigned int pinky : 1;
        unsigned int ring : 1;
        unsigned int middle : 1;
        unsigned int index : 1;
        unsigned int thumb : 1; //bit0
    } flags;
    struct {
        //PowerPC compilers put bit 15 at top of bitfield, bit 0 at bottom!
		unsigned int reserved : 8;
        unsigned int fingers : 8;   
    } fields;
} FWHID_FingerSpecifier;

#else //Intel architectures are little Endian

typedef union {
    unsigned short word;
    struct {
        //Intel compilers put bit 0 at top of bitfield, bit 15 at bottom!
        unsigned int thumb : 1; //bit0
        unsigned int index : 1;
        unsigned int middle : 1;
        unsigned int ring : 1;
        unsigned int pinky : 1;
        unsigned int outerPalm : 1;
        unsigned int innerPalm : 1;
        unsigned int forePalms : 1;
		unsigned int reserved : 8;
    } flags;
    struct {
        //Intel compilers put bit 0 at top of bitfield, bit 15 at bottom!
        unsigned int fingers : 8;   
		unsigned int reserved : 8;
    } fields;
} FWHID_FingerSpecifier;

#endif //endianess

/**  The FWHID_HandMotion data structure is analogous to the mouse or tablet event available in most GUI programming environments, with 'selectedChord' and 'currentFingers' instead of buttons, and Xtrans/Ytrans/Ztrans/Zrot replacing x,y,z motion. 
@brief All hand motion event data is stored and passed in FWHID_HandMotion structures. 
*/
typedef struct {
	/** @brief Indicates the initial chord selection, i.e. the combination and arrangement of fingers when hand motion started.  Not allowed to change until all fingers lift. */
    FWHID_ChordSpecifier selectedChord;	
    FWHID_ChordSpecifier lastChord;/**<@brief Copy of selectedChord info from the previous image frame */
	/** @brief Indicates which fingers are still touching in the current frame, regardless of originally selected chord. */ 
    FWHID_FingerSpecifier currentFingers; 	
    FWHID_FingerSpecifier lastFingers;/** <@brief Copy of currentFingers info from the previous image frame */
	/** @brief Special codes for XWinder min/max commands or other discrete action commands on this channel */
    unsigned handActionCode;
	/** @brief Indicates total pressure or contact area from this hand (with a standard fingertip contributing ~256 levels). */
    unsigned handPressure;
	
    unsigned lastPressure;/**<@brief Copy of handPressure info from the previous image frame */
	
	float handPositionX; /**<@brief Horizontal distance of hand from home row or surface center (in cm at 25um resolution). */	
	float handPositionY; /**<@brief Vertical distance of hand from home row or surface center (in cm at 25um resolution). */
    int Xtrans;  /**<@brief X axis hand motion (in mickeys or pixels) */
    int Ytrans;  /**<@brief Y axis hand motion (in mickeys or pixels) */
    int Ztrans; /**<@brief Hand scaling/expansion motion (AKA zoom in mickeys or pixels) */
    int Xrot; /**<@brief this axis inactive as of Firmware v1.53*/
    int Yrot; /**<@brief this axis inactive as of Firmware v1.53*/
    int Zrot; /**<@brief Hand rotation motion (in mickeys or pixels) */
    int Xscale;         /**<@brief this axis inactive as of Firmware v1.53*/
    int Yscale;         /**<@brief this axis inactive as of Firmware v1.53*/
    int Zscale;         /**<@brief this axis inactive as of Firmware v1.53*/
	/** @brief Special gesture report code indicating the direction or collection of axes active for this gesture. */
	unsigned slideAxesCode;
} FWHID_HandMotion, *FWHID_HandMotionPtr;


/*  NOTE:  Receiver does not 'own' the data pointed to by handMotionDatap!
   It's a stack-allocated copy.  */
typedef void (*FWHIDHandEventCALLBACK)
(int handEventID, FWHID_HandMotionPtr pHandMotion);


//NOTE:  Your Windows App's event processing loop must also call FWHID_WndProc() (see FWHID_PlatformDefs.h) as a default processor for WM_INPUT and/or WM_DEVICE_CHANGED messages

/**  Your application must set a callback with this function so it can receive hand events! */
void FWHID_setHandEventCallback(FWHIDHandEventCALLBACK fwcallback);
/**  Your application can find out what callback was set with this function. */
FWHIDHandEventCALLBACK FWHID_getHandEventCallback(void);

//this default hand event callback just prints the hand motion event to stdout (console)
void FWHID_printHandMotion(int handEventID, FWHID_HandMotionPtr pHandMotion);

int FWHID_snprintfHandMotion(char *buffer, size_t bufsize, int handEventID, FWHID_HandMotionPtr pHandMotion);

#ifdef __cplusplus
}
#endif

#endif // _FWHID_HandMotion_h_

