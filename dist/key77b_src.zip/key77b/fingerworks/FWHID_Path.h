/**
 *  @file FWHID_Path.h
 *  @brief FW Hand Tracking SDK -- Paths Header.
 *  @brief <p>A path stores the current trajectory of an independent finger or palm surface contact.
 *
 *  @author Created by Wayne Westerman on Wed Jun 25 2003.
 *  @author Last Updated Wayne Westerman on Wed Dec 8 2003.

  *  v1.53 Changed path status macros into static inline functions.

 */
/*
 *  Copyright (c) 2003-2004 FingerWorks, Inc. All rights reserved.
 *
	IMPORTANT:  		This FingerWorks software is supplied to you by FingerWorks, Inc.
				("FingerWorks") in consideration of y]our agreement to the following terms, and your
				use, installation, or modification of this FingerWorks software
				constitutes acceptance of these terms.  If you do not agree with these terms,
				please do not use, install or modify this FingerWorks software.

				In consideration of your agreement to abide by the following terms, and subject
				to these terms, FingerWorks grants you a personal, non-exclusive license, under FingerWorks's
				copyrights in this original FingerWorks software (the "FingerWorks Software"), to use,
				reproduce, and modify the FingerWorks Software for personal, academic, research, or artistic purposes.
                                You may NOT distribute this FingerWorks Software, with or
                                without modifications, in either source or binary form.

                                Neither the name, trademarks, service marks or logos of
				FingerWorks, Inc. may be used to endorse or promote products derived from the
				FingerWorks Software without specific prior written permission from FingerWorks.  Except as
				expressly stated in this notice, no other rights or licenses, express or implied,
				are granted by FingerWorks herein, including but not limited to any patent rights that
				may be infringed by your derivative works or by other works in which the FingerWorks
				Software may be incorporated.

	Disclaimer:		The FingerWorks Software is provided by FingerWorks on an "AS IS" basis.  FINGERWORKS MAKES NO
				WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
				WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
				PURPOSE, REGARDING THE FINGERWORKS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
				COMBINATION WITH YOUR PRODUCTS.

				IN NO EVENT SHALL FINGERWORKS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
				CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
				GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
				ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR DISTRIBUTION
				OF THE FINGERWORKS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF CONTRACT, TORT
				(INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF FINGERWORKS HAS BEEN
				ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef _FWHID_Path_h_
#define _FWHID_Path_h_

#include "FWHID_Contact.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
@brief FWHID_Path is the structure that holds all the data about a Path
*/
typedef struct {
	/**@brief The number of frames the Path has been in contact with the surface
	*/
    int frames_touching;
	/**@brief The number of debouncing frames.
	*/
    int frames_invalid;
	/**In device milliseconds
	@brief The time the path started
	*/
    long tpress_ms; //device milliseconds
	/**In device milliseconds
	@brief The time the path stopped
	*/
    long trelease_ms; //device milliseconds
	/**
	@brief The unique identifier of this path
	*/
    int path_id;
	/** The finger identification system does not try to assign an identity
    to a contact during the press debounce frame (identity should be
    kFWHIDunidentified).  But it does update identity
    estimates for all valid frames thereafter and for the release debounce frame.

    <p>The final_finger_id continues to hold the last known
    identity for inactive paths with frames_invalid > 1.  Keep in mind that a
    newer path may acquire the same identity, say Right Index, of an inactive path.
    Identity assignments are therefore only 1-to-1 among those paths whose
    identities are "current." 
	@brief the finger id for this Path
	*/
    FWHIDfingerID final_finger_id;
	/** The hand identification system does not try to assign an identity
    to a contact during the press debounce frame (identity should be
    kFWHIDunknownHand).  But it does update identity
    estimates for all valid frames thereafter and for the release debounce frame.

    <p>The final_hand_id continues to hold the last known
    identity for inactive paths with frames_invalid > 1.  Keep in mind that a
    newer path may acquire the same identity, say Right Index, of an inactive path.
    Identity assignments are therefore only 1-to-1 among those paths whose
    identities are "current." 
	@brief The hand id for this path
	*/
    FWHIDhandID final_hand_id;
	/**
	@brief The current contact in this Path
	*/
    FWHID_Contact current_contact;
	/**
	@brief The previous contact in this Path 
	*/
    FWHID_Contact previous_contact;
} FWHID_Path, *FWHID_PathPtr;


//set this callback to receive notification of new frame of paths
/**
The function pointed to by fwcallback is called everytime the device pointed to by fwdevice receives
a complete frame of data.
@brief Sets the Path Frame callback
@param fwdevice The device of interest
@param fwcallback A pointer to a function to handle Path Frame Events for a given device
*/
extern void FWHID_setPathFrameCallback(FWMultiTouchDevicePtr fwdevice,FWHIDCallbackFunction fwcallback);

//use these functions in callback to access latest paths
/**

@brief Retrieves a copy of the path array from the device.
@param fwdevice the device of interest
@param path_copies a pre-allocated array with size sizeof(FWHID_Path)*kFWHID_MAX_CONTACT_PATHS that paths will be copied into.
@return The total number of bytes actually copied.  Zero or less than sizeof(FWHID_Path)*kFWHID_MAX_CONTACT_PATHS if something went wrong.
*/
extern int FWHID_getPaths(FWMultiTouchDevicePtr fwdevice,FWHID_Path path_copies[kFWHID_MAX_CONTACT_PATHS]);

/**
@brief Accesses a certain Path from a device
@param fwdevice the device of interest
@param path_id the path_id of the Path of interest
@return FWHID_PathPtr to the Path requested
*/
extern FWHID_Path FWHID_getPath(FWMultiTouchDevicePtr fwdevice,int path_id);

/**
Gesture recognition programs should use this test function to determine which paths to process or pay attention to.  It ignores "noise" or "press debounce" contacts which touch for one frame only and then disappear.  No finger/hand identities are assigned to such "noise" contacts.

However, it returns true during "release debounce" so that path continuity and identities are maintained should a contact disappear for one frame and then re-appear.

@brief Tests whether finger/hand identities have been assigned to a path and the path is active.@param pPath is a pointer to an FWHID_Path
@return true if identities are valid, false if path not yet identified or permanently lifted.
*/
static inline bool FWHID_isPathIdentityCurrent(FWHID_PathPtr pPath) {
	return (pPath->frames_touching > 1 && pPath->frames_invalid <= 1);
}

/**
	
@brief Tests whether the path has a valid contact/touch in the current image frame. 
@param pPath is type FWHID_PathPtr
*/
static inline bool FWHID_isPathTouching(FWHID_PathPtr pPath) {
	return pPath->frames_invalid == 0;
}

/**
@brief Tests whether the path is undergoing either press debounce (only been touching for one frame) 
	or release debounce (only been lifted for one frame). 
 
@param pPath is type FWHID_PathPtr
@return True if this is a new path's first frame of contact or if the contact
    has been missing for a single frame.  False if the path has been either touching or lifted for more than one frame.
*/
static inline bool FWHID_isPathDebouncing(FWHID_PathPtr pPath) {
	return	(pPath->frames_touching == 0 || pPath->frames_invalid == 1);
}


/** 
@brief Prints description of all active (FWHID_isPathIdentityCurrent() true) paths.
@param buf pointer to pre-allocated character buffer that output string will be put in.
@param bufsize size of pre-allocated character buffer.
@param fwdevice pointer to multi-touch device structure
@param contact_info_only suppresses printing of path press-release times, frames_touching, etc.
@return The length of string printed into buf. */
extern int FWHID_snprintfActivePaths(char *buf, size_t bufsize, FWMultiTouchDevicePtr fwdevice, bool contact_info_only);

#ifdef __cplusplus
}
#endif

#endif // _FWHID_Path.h

