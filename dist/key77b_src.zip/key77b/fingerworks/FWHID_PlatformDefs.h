/**
 *  @file FWHID_PlatformDefs.h
 *  @brief FW Hand Tracking SDK -- Platform Definitions
 *
 FingerWorks HID Hand Tracking SDK (External API)
 *
 *  @author Created by Wayne Westerman on Wed Jun 25 2003.
  * @author Last Updated by James Orr on Tue Aug 17 2004.
	@version 1.0
	*
  *  v0.65 fixed FWHID_ZoneSpecifier for little endian
  *  
  v1.0 changed FWHID_ZoneSpecifier to FWHID_FingerSpecifier, and added handActionCode and handPositionX/Y
  
  * Copyright (c) 2003-2004 FingerWorks, Inc. All rights reserved. 
  **/
 /* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is FWHID_PlatformDefs.h, 
 *   External API for FingerWorks HID Hand Motion SDK.
 *
 * The Initial Developer of the Original Code is
 * Wayne Westerman, FingerWorks, Inc.
 *
 * Portions created by the Initial Developer are Copyright (C) 2003-2004
 * by FingerWorks Inc. All Rights Reserved.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */
 

#ifndef _FWHID_PlatformDefs_h_
#define _FWHID_PlatformDefs_h_

#ifdef __cplusplus
extern "C" {
#endif


	

#if defined(WIN32)
#include <windows.h>
/**This function is necessary for the SDK to function.
@brief Windows message handler that must be called to handle WM_DEVICE_CHANGED and WM_INPUT messages
@param hwnd Handle to a Window
@param nMsg The actual message
@param wParam The wParam from the Window Message handler routine
@param lParam The lParam from the Window Message handler routine
*/
LRESULT CALLBACK FWHID_WndProc (HWND hwnd, UINT nMsg, WPARAM wParam, LPARAM lParam);

typedef double FWHID_AbsoluteTime;
#define snprintf _snprintf

 #if !defined(__cplusplus) //make Mac-style bool for Windows
#ifndef bool
typedef unsigned char bool;
#endif //bool
#define false 0
#define true 1
#define inline __inline
#endif //__cplusplus

  #elif defined(__APPLE__)  //useful headers only available on Mac OS X
#include <CoreFoundation/CoreFoundation.h>
#include <stdbool.h>  
#include <unistd.h>   
typedef AbsoluteTime FWHID_AbsoluteTime;

  #elif defined(__LINUX__)

  #endif //platform-dependent declarations

//these are needed by other public headers:
typedef unsigned char FWBYTE;

/**
@brief Stores all information about a particular MultiTouch Device.
*
To access any of FWMultiTouchDevicePtr fields use the functions declared in FWHID_MultiTouchDevice.h.
@sa ::FWHID_getProductName(), ::FWHID_getSurfaceVersion(), ::FWHID_getProcessorVersion(), ::FWHID_getKeymatrixVersion(), ::FWHID_getSurfaceDimensions()
*/
typedef struct fw_multitouchdevice_t *FWMultiTouchDevicePtr;

typedef void (*FWHIDCallbackFunction) (FWMultiTouchDevicePtr   fwdevice, void *targetData);

#ifdef __cplusplus
}
#endif

#endif // _FWHID_PlatformDefs_h_

