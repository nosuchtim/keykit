/**
 *  @file FWHID_Contact.h
 *  @brief FW Hand Tracking SDK -- Contacts Header
 *
 *  @author Created by Wayne Westerman on Wed Jun 25 2003.
 *  @author Last Modified by James Orr on Mon Aug 16 2004.
	@version 1.0


 *  Copyright (c) 2003 FingerWorks, Inc. All rights reserved.
 *
	IMPORTANT:  		This FingerWorks software is supplied to you by FingerWorks, Inc.
				("FingerWorks") in consideration of your agreement to the following terms, and your
				use, installation, or modification of this FingerWorks software
				constitutes acceptance of these terms.  If you do not agree with these terms,
				please do not use, install or modify this FingerWorks software.

				In consideration of your agreement to abide by the following terms, and subject
				to these terms, FingerWorks grants you a personal, non-exclusive license, under FingerWorks's
				copyrights in this original FingerWorks software (the "FingerWorks Software"), to use,
				reproduce, and modify the FingerWorks Software for personal, academic, research, or artistic purposes.
                                You may NOT distribute this FingerWorks Software, with or
                                without modifications, in either source or binary form.

                                Neither the name, trademarks, service marks or logos of
				FingerWorks, Inc. may be used to endorse or promote products derived from the
				FingerWorks Software without specific prior written permission from FingerWorks.  Except as
				expressly stated in this notice, no other rights or licenses, express or implied,
				are granted by FingerWorks herein, including but not limited to any patent rights that
				may be infringed by your derivative works or by other works in which the FingerWorks
				Software may be incorporated.

	Disclaimer:		The FingerWorks Software is provided by FingerWorks on an "AS IS" basis.  FINGERWORKS MAKES NO
				WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
				WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
				PURPOSE, REGARDING THE FINGERWORKS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
				COMBINATION WITH YOUR PRODUCTS.

				IN NO EVENT SHALL FINGERWORKS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
				CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
				GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
				ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR DISTRIBUTION
				OF THE FINGERWORKS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF CONTRACT, TORT
				(INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF FINGERWORKS HAS BEEN
				ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef _FWHID_Contact_h_
#define _FWHID_Contact_h_


#ifdef __cplusplus
extern "C" {
#endif

#include "FWHID_HandMotion.h"

#define kFWHID_NULL_PATH_ID 0 /**<@brief path_id 0 is reserved for null, non-existent paths.  i.e. Ignore anything with path_id 0*/
#define kFWHID_MAX_iGesture_PATHS 10 /**<@brief iGesture products currently use up to 10 paths*/
#define kFWHID_MAX_TouchStream_PATHS 24 /**<@brief TouchStream products currently use up to 24 paths*/
#define kFWHID_MAX_CONTACT_PATHS 32 /**<@brief never expect a two-handed FingerWorks product to use > 32 paths*/

typedef enum FWHIDhandID {
    kFWHIDleftHand = -1,/**<@brief Left Hand*/
    kFWHIDunknownHand = 0,/**<@brief Unknown Hand*/
    kFWHIDrightHand = +1 /**<@brief Right Hand*/
} FWHIDhandID;

typedef enum FWHIDfingerID {
    kFWHIDunidentified = 0, /**<@brief Unknown Finger*/
    kFWHIDthumb = 1,	/**<@brief Thumb*/
    kFWHIDindex = 2,	/**<@brief Index Finger*/
    kFWHIDmiddle = 3,	/**<@brief Middle Finger*/
    kFWHIDring = 4,		/**<@brief Ring Finger*/
    kFWHIDpinky = 5,	/**<@brief Pinky Finger*/
    kFWHIDinnerPalm = 6,
    kFWHIDouterPalm = 7,
    kFWHIDforePalm0 = 8,
    kFWHIDforePalm1 = 9,
    kFWHIDforePalm2 = 10,
    kFWHIDforePalm3 = 11,
    kFWHIDforeArm0 = 12,
    kFWHIDforeArm1 = 13,
    kFWHIDhandCenter = 14,
    kFWHID_MAX_CONTACTS_PER_HAND = 15 /**<@brief Maximum number of Contacts for a single hand*/ //fingers, palms, forepalms, forearms, etc.
} FWHIDfingerID;

/**
A contact is a single contiguous surface image (typically fingers) which contains all the relevant position,
velocity, and proximity/pseudo-pressure data. The contact is assigned a path_id with is constant across all consecutive 
frames where the contact is touching the surface. Also the device takes a best guess 
at which finger the contact is (@link FWHID_Contact::finger_id finger_id@endlink). This guess changes as more contacts touch the surface.
@brief Structure containing the all the information about a Contact
*/
typedef struct { //fwhid_contact_t
	/**The range of values is 0-255 and then wraps around.
	@brief The current frame number assigned by the device.
	*/
    int frame_no; 
    /**The pathID is constant across all consecutive frames where the contact is touching the surface.
	@brief 1 to MAX_PATHS-1*/
	int path_id;
	/**
	 The finger_id is may not be constant across frames. It can change as more contacts touch the surface. If all
	 five fingers from one hand touch the surface the finger_id's will mostly likely be all correct.
	 @brief Best guess of which finger this Contact represents
	 @note This is really type ::FWHIDfingerID
	 @sa FWHID_isPalm(), FWHID_isFinger(), FWHID_isFingerNotThumb()
	*/
    int finger_id; 
	/**
	 @brief Best guess of which hand this Contact belongs to
	 @note This is really type ::FWHIDhandID
	*/
    int hand_id;
	/**
	This member and @link FWHID_Contact::untouch untouch @endlink comprise the debouncing of a contact.
	\li When a Contact first touches the surface, identity_active=false and untouch=false.
	\li On the next frame, if the Contact
	still exsists, identity_active=true, debounce=0 and the indentites are assigned to the Contact. 
	\li If the Contact leaves the surface for one frame, identity_active = true and untouch = true. 
	\li If on the following frame the Contact is still off of the surface then, identity_active = false and untouch = true otherwise, identity_active = true and untouch = false.
	\n <table border="0"><tr><td>identity_active</td><td> untouch</td><td>&nbsp;</td></tr>
	\n<tr><td>false</td><td>false</td><td> Touch down debounce frame </td></tr>
	\n<tr><td>true</td><td>false</td><td> Contact Active </td></tr>
	\n<tr><td>true</td><td>true</td><td> Lift off debounce frame </td></tr>
	\n<tr><td>false</td><td>true</td><td> Contact lifted off </td></tr>
	\n</table>
	@brief Indicates that the Contact is debounced and active.
	@sa FWHID_Contact::untouch
	*/
	bool identity_active; //bool
	/** See @link FWHID_Contact::identity_active identity_active @endlink for a description of how this member
	is used to debounce Contacts
	@brief Used for debouncing the Contact
	*/
    bool untouch; //bool
	/**
	The coordinate is defined in centimeters.
	@brief The X (horizontal) coordinate of the center of the Contact.
	*/
    double xpos; //centimeters
	/**
	The coordinate is defined in centimeters.
	@brief The Y (vertical) coordinate of the center of the Contact.
	*/
    double ypos; //centimeters 	
	/**
	The velocity is defined in millimeters/second.
	@brief The X (horizontal) velocity of the Contact.
	*/
    double xvel; //millimeters/second 	
	/**The velocity is defined in millimeters/second.
	@brief The Y (vertical) velocity of the Contact.
	*/
    double yvel; //millimeters/second
	
	/**The proximity is approximatly defined in square centimeters. The proximity data can be used at pseudo-pressure data.
	@brief The normalized fingertip area/pressure of the Contact.
	*/
    double proximity;
	/**
	The range of values is 0 to 180 degrees with a nominal values of 90.
	@brief Represents the orientation of the contact.
	*/
    double orientation; //degrees 0-180
	/**
	The range is from 1 to 7.2 with a nominal value of ~1.8
	@brief Ratio of height/width of the Contact.
	*/
    double eccentricity; //ratio from 1 to 7.2, default ~1.8
	/**
	The range is ???????
	@brief Timestamp of the Contact assigned by the device in milliseconds.
	*/
    long device_timestamp; //milliseconds
	/**

	@brief Timestamp of the Contact assigned by the host OS.
	*/
    FWHID_AbsoluteTime host_timestamp;
} FWHID_Contact, *FWHID_ContactPtr;


/**
@brief Structure containing the all the information about a Contact frame.
*/
typedef struct {
	/**
	@brief The frame number of this frame
	*/
	int frame_no;
	/**
	@brief The number of contacts in this frame.
	*/
	int contact_count;
	/**
	@brief An array of Contacts
	*/
	FWHID_Contact contacts[kFWHID_MAX_CONTACT_PATHS];
} FWHID_ContactFrame,*FWHID_ContactFramePtr;


//contact print/debug function
/**
@brief Converts a Contact to a string.
Useful for debugging.
@param pContact Pointer to the contact
@param *buf Pointer to a pre-allocated char buffer. 
@param bufsize The size of the allocated buffer.
@return The length of the string pointed to by buf.
*/
extern int FWHID_snprintfContact(char *buf, size_t bufsize, FWHID_ContactPtr pContact);



//callbacks from various stages of contact processing

//set to receive each contact as it comes in
/**
The callback function will be called everytime a contact is received 
and a pointer to the contact will be the second argument in the callback function.
	@brief Set the callback function for individual Contacts
		@param fwdevice device of interest
	@param fwcallback function pointer of type ::FWHIDCallbackFunction
*/
void FWHID_setContactCallback(FWMultiTouchDevicePtr fwdevice, FWHIDCallbackFunction fwcallback);

//set to receive all contacts from an image frame at once
/**
The callback function will be called everytime a complete frame is received. To get the actual data
the program should call ::FWHID_getContactFrame(),
	@brief Set the callback function for when a Contact Frame is received
	@param fwdevice device of interest
	@param fwcallback function pointer of type ::FWHIDCallbackFunction
	@sa FWHID_getContactFrame()
*/
//extern void FWHID_setContactFrameCallback(FWMultiTouchDevicePtr fwdevice, FWHIDCallbackFunction fwcallback);
extern void FWHID_setContactFrameCallback(FWMultiTouchDevicePtr fwdevice, void *fwcallback);

//use this in your ContactFrameCallback to retrieve array of contacts...
/**
	@param fwdevice device of interest
	@param contact_frame A pointer to an allocated buffer of size sizeof(FWHID_ContactFrame).
	@brief Retrieves the current Contact frame
*/
extern void FWHID_getContactFrame(FWMultiTouchDevicePtr fwdevice,FWHID_ContactFramePtr contact_frame);

//centimeter to pixel conversion functions for screen drawing...
// Supply the device, latest contact and screen size and these will give you contact position scaled to screen pixels
extern int FWHID_getXpixelForScreen(FWMultiTouchDevicePtr fwdevice,FWHID_ContactPtr pContact, int max_width);

extern int FWHID_getYpixelForScreen(FWMultiTouchDevicePtr fwdevice, FWHID_ContactPtr pContact, int max_height);

extern int FWHID_getYpixelForScreenBottomOrigin(FWMultiTouchDevicePtr fwdevice, FWHID_ContactPtr pContact, int max_height);

extern char * FWHID_getFingerName(int finger_id);
extern char * FWHID_getHandName(int hand_id);


//common finger identity tests
//Maybe these should be macros -- now they are
	/**
	Returns true if the finger_id is a thmub or finger.
	@brief Tests to see if a finger_id is a finger (including thumb).
	*/
#define FWHID_isFinger(finger_id) ((finger_id >= kFWHIDthumb && finger_id <= kFWHIDpinky) ?true:false)
	/**
	Returns true if the finger_id is a finger and not a thumb.
	@brief Tests to see if a finger_id is a finger (excluding thumb).
	*/
#define FWHID_isFingerNotThumb(finger_id) ((finger_id > kFWHIDthumb && finger_id <= kFWHIDpinky) ?true:false)
	/**
	Returns true if the finger_id is a palm or forepalm.
	@brief Tests to see if a finger_id is a palm.
	*/
#define FWHID_isPalm(finger_id) ((finger_id>=kFWHIDinnerPalm && finger_id <= kFWHIDforePalm3)?true:false)


#ifdef __cplusplus
}
#endif

#endif // _FWHID_Contact.h

