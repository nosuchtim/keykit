/**@file FWHID_MultiTouchDevice.h
 @brief FW Hand Tracking SDK -- Main header for SDK
 @author Created by Wayne Westerman on Wed Jun 25 2003.
 @author Last Modified by James Orr on Mon Aug 14 2004.
 @version 1.0

 Copyright (c) 2003 FingerWorks, Inc. All rights reserved.

	IMPORTANT:  		This FingerWorks software is supplied to you by FingerWorks, Inc.
				("FingerWorks") in consideration of your agreement to the following terms, and your
				use, installation, or modification of this FingerWorks software
				constitutes acceptance of these terms.  If you do not agree with these terms,
				please do not use, install or modify this FingerWorks software.

				In consideration of your agreement to abide by the following terms, and subject
				to these terms, FingerWorks grants you a personal, non-exclusive license, under FingerWorks
				copyrights in this original FingerWorks software (the "FingerWorks Software"), to use,
				reproduce, and modify the FingerWorks Software for personal, academic, research, or artistic purposes.
                                You may NOT distribute this FingerWorks Software, with or
                                without modifications, in either source or binary form.

                                Neither the name, trademarks, service marks or logos of
				FingerWorks, Inc. may be used to endorse or promote products derived from the
				FingerWorks Software without specific prior written permission from FingerWorks.  Except as
				expressly stated in this notice, no other rights or licenses, express or implied,
				are granted by FingerWorks herein, including but not limited to any patent rights that
				may be infringed by your derivative works or by other works in which the FingerWorks
				Software may be incorporated.

	Disclaimer:		The FingerWorks Software is provided by FingerWorks on an "AS IS" basis.  FINGERWORKS MAKES NO
				WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
				WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
				PURPOSE, REGARDING THE FINGERWORKS SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
				COMBINATION WITH YOUR PRODUCTS.

				IN NO EVENT SHALL FINGERWORKS BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
				CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
				GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
				ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR DISTRIBUTION
				OF THE FINGERWORKS SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF CONTRACT, TORT
				(INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF FINGERWORKS HAS BEEN
				ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef _FWHID_MultiTouchDevice_h_
#define _FWHID_MultiTouchDevice_h_

#define COMPILE_HANDFINGER_STATS 0

// The public API is in these other header files...
#include "FWHID_PlatformDefs.h"
#include "FWHID_HandMotion.h"

#include "FWHID_Contact.h"
#include "FWHID_Path.h"

 #if COMPILE_HANDFINGER_STATS
#include "FWHID_HandFingerStats.h"
 #endif //COMPILE_HANDFINGER_STATS


#ifdef __cplusplus
extern "C" {
#endif

/**
@note This list is not exhaustive and only includes processor versions that are commercially available .
@brief Enumeration Type used to determine which processor version of the MultiTouch Device.
@sa FWHID_getProcessorVersion()
*/
typedef enum FWProcessorVersion {
	kFW_iGesture_Processor = 4,
    kFW_touchStream_Processor = 5,
    kFW_touchStreamB_Processor = 6,
    kFW_digitaliGesturePad_Processor = 8,
    kFW_digitalTouchStream_Processor = 9,
	kFW_WinPad_Processor = 16,
} FWProcessorVersion;

/**
@brief Enumeration Type used to determine what type of MultiTouch device is attached.
@sa FWHID_getSurfaceVersion()
*/
typedef enum FWSurfaceVersion {
	kFW_DFU_Surface = 0, /**<The Device Firmware Upgrade*/
    kFW_iGesturePad_Surface = 7, /**<iGesture Pad includes Winpad use surface version to distinguish*/
    kFW_iGestureNumPad_Surface = 8, /**<iGesture NumPad*/
    kFW_iGestureRetro_Surface = 9, /**<iGesture Retro Keyboard*/
    kFW_iGestureMini_Surface = 10, /**<iGesture Mini*/
    kFW_TouchStreamLP_Surface = 11, /**<TouchStream LP*/
    kFW_TouchStreamUltrathin_Surface = 12, /**<TouchStream Ultrathin - Not commercially available at this time*/
    kFW_TouchStreamMacNTouch_Surface = 13, /**<TouchStream MacNTouch*/
    kFW_TouchStreamTablet_Surface = 17    /**<Not commercially available*/
} FWSurfaceVersion;

/**
@brief Enumeration Type used to determine what the key layout is on a MultiTouch device.
@sa FWHID_getKeymatrixVersion()
*/
typedef enum FWKeymatrixVersion {
	kFW_Default_Keymatrix = 0, /**<Default Key layout*/
	kFW_SlantedST_Keymatrix = 32, /**<Old Key layout for ST/LP's. Only available for couple of months. Keys on left half have a svere slant*/
	kFW_StraightST_Keymatrix = 33,/**<Old Key layout for ST/LP's. Stopped being available in 2003.*/
	kFW_MirroredST_Keymatrix = 34,/**<Current Key layout for LP's.*/
	kFW_MacNTouch_Keymatrix = 41, /**<Current Key layout for MacNTouch's.*/
} FWKeymatrixVersion;

/**@brief Enumeration Type used for enabling/disabling the data streams on a MultiTouch device.
@sa FWHID_setStreamEnables(), FWHID_getStreamEnables()
*/
typedef enum FWStreamEnablesMask {
	kFW_NoStreams = 0, /**<Disables all streams */
	kFW_KeyboardStream = 0x1, /**<Keyboard Stream*/
	kFW_MouseStream = 0x2, /**<Mouse Stream*/
	kFW_MultimediaStream = 0x4, /**<Multimedia Stream*/
	kFW_HandMotionStream = 0x8, /**<Hand Motion Stream (used by Xwinder)*/
	kFW_DefaultStreams = 0xF, /**<Equal to kFW_KeyboardStream | kFW_MouseStream | kFW_MultimediaStream | kFW_MotionStream*/

    kFW_ContactPathStream = 0x10, /**<ContactPath Data Stream*/
	kFW_ImageStream = 0x20, /**<Surface Image Data Stream*/
	kFW_ReservedStream = 0x40,  /**<Reserved Data Stream*/
	kFW_GestureReportStream = 0x80  /**<Extra info about every gesture activation (sent over Hand Motion channel for gesture game) */
} FWStreamEnablesMask;

/**@brief Enumeration Type used for enabling/disabling ?????????? a MultiTouch device.
@sa FWHID_setProcessingEnables(), FWHID_getProcessingEnables()
*/
typedef enum FWProcessingEnablesMask {
	kFW_FlathandResetProcessing = 0x1, /**<Re-calibrates imaging when whole surface covered by hand*/
	kFW_GestureProcessing = 0x2, /**<Re-calibrates imaging when whole surface covered by hand*/
	kFW_DefaultProcessing = 0x3, /**<equiv to kFW_FlathandResetProcessing | kFW_GestureProcessing*/
} FWProcessingEnablesMask;

/**
@brief Structure containing the dimensions and the left and bottom edges for the coordinates used on a MultiTouch Surface.
@sa FWHID_getSurfaceDimensions()
*/
typedef struct {
	/**@brief The left most dimension*/
    double left_edge;
	/**@brief The bottom most dimension*/
    double bottom_edge;
	/**@brief The width of the device surface in centimeters*/
    double width_cm;
	/**@brief The height of the device surface in centimeters*/
    double height_cm;
} FWSurfaceRectangle, *FWSurfaceRectanglePtr;



// public API declarations ----------------------------------------------------------

//callbacks from device creation/removal...must be set BEFORE call to FWHID_registerMultiTouchDevices!
/**
The device diposal callback is called anytime a device is removed from the internal list of devices kept by
the SDK library. This occurs when I a device is unplugged. It also occurs when a new device is plugged b/c
the entire internal list is disposed and rebuilt causing the device disposal callback to be called as well
as the creation callback when each device is rediscovered.
@note The disposal callback must be set BEFORE ::FWHID_registerMultiTouchDevices() is called!
@brief Set the Device Disposal Callback.
@param fwcallback a function pointer to a function to handle device disposal events.
@sa FWHID_getDeviceDisposalCallback(), FWHID_setDeviceCreationCallback(), FWHID_registerMultiTouchDevices()
*/
extern void FWHID_setDeviceDisposalCallback(FWHIDCallbackFunction fwcallback);

/**
@brief Returns the current Device Disposla Callback Function
@return A function pointer to the callback function of type ::FWHIDCallbackFunction
@sa FWHID_setDeviceDisposalCallback()
*/
extern FWHIDCallbackFunction FWHID_getDeviceDisposalCallback(void);

/**
The creation diposal callback is called anytime a device is added to the internal list of devices kept by
the SDK library. This occurs when I a device is plugged in. It also occurs when a device is unplugged b/c
the entire internal list is disposed and rebuilt causing the device disposal callback to be called as well
as the creation callback when each device is rediscovered.
@brief Sets the Device Creation Callback
@param fwcallback a function pointer to a function to handle device creation events.
@note The creation callback must be set BEFORE ::FWHID_registerMultiTouchDevices() is called!
@sa FWHID_getDeviceCreationCallback(), FWHID_setDeviceDisposalCallback(), FWHID_registerMultiTouchDevices()
*/
extern void FWHID_setDeviceCreationCallback(FWHIDCallbackFunction fwcallback);

/**
@brief Returns the current Device Creation Callback Function
@return A function pointer to the callback function of type ::FWHIDCallbackFunction
@sa FWHID_setDeviceCreationCallback()
*/
extern FWHIDCallbackFunction FWHID_getDeviceCreationCallback(void);

//NOTE:  Your Windows App's event processing loop must also call FWHID_WndProc() (see FWHID_PlatformDefs.h) as a default processor for WM_INPUT and/or WM_DEVICE_CHANGED messages

//for public startup/shutdown of this library
/**
@brief The startup function required to initialize the FingerWorks Hand Tracking SDK lbrary.

The callbacks for device creation/disposal <b>MUST</b> be set <b>BEFORE</b> the call to FWHID_registerMultiTouchDevices!
@param targetWindow Handle to the main Application Window (HWND).
@sa FWHID_setDeviceCreationCallback(), FWHID_setDeviceDisposalCallback(), FWHID_releaseMultiTouchDevices()
*/
extern void FWHID_registerMultiTouchDevices(void* targetWindow);

/**
@brief Finalizes the SDK library

Should be called when the apllication is exiting to clean up/close down the SDK lib.
@sa FWHID_registerMultiTouchDevices()
*/
extern void FWHID_releaseMultiTouchDevices(void);  //????? should we pass the handle to the window here?? eventhrouh we don't need it

/**
  This function uses getFeature/setFeature requests to ensure specified report streams are enabled on the device.
  Already-enabled streams (such as the default key/mouse/hand-motion streams) are not affected.
  @brief For enabling various HID data streams from each device.
  @param fwdevice The device of interest
  @param stream_mask A byte containing the mask defining which additional streams to enable. Use the enumerated type ::FWStreamEnablesMask.
  @return Whether the underlying HID Get/Set Feature I/O calls were successful. NOTE:  Check for failure on unsupported streams or operating systems.
  @note Must be called inside of @link ::FWHID_setDeviceCreationCallback() Device Creation Callback @endlink or the @link ::FWHID_setDeviceDisposalCallback() Device Disposal Callback @endlink.
  @sa FWHID_disableStreams(), FWHID_getStreamEnables()
*/
extern bool FWHID_enableStreams(FWMultiTouchDevicePtr fwdevice, FWBYTE stream_mask);

/**
  This function uses getFeature/setFeature requests to ensure specified report streams are disabled on the device.
  @brief For disabling various HID data streams from each device.
  @param fwdevice The device of interest
  @param stream_mask A byte containing the mask defining which streams to disable. Use the enumerated type ::FWStreamEnablesMask.  Streams not specified in stream_mask are not affected.
  @return Whether the underlying HID Get/Set Feature I/O call were successful. NOTE:  Check for failure on unsupported streams or operating systems.
  @note Must be called inside of @link ::FWHID_setDeviceCreationCallback() Device Creation Callback @endlink or the @link ::FWHID_setDeviceDisposalCallback() Device Disposal Callback @endlink.
  @sa FWHID_enableStreams(), FWHID_getStreamEnables()
*/
extern bool FWHID_disableStreams(FWMultiTouchDevicePtr fwdevice, FWBYTE stream_mask);


/**
  @brief Retrieves the state of the various HID data streams from a device
  @param fwdevice The device of interest
  @param *stream_mask A pointer to an allocated byte which will contain the mask defining which streams are enabled.
  @return If the mask was retrieved successfully returns true, else it returns false and the stream_mask will equal ::kFW_DefaultStreams.

  @sa FWHID_enableStreams()
  @sa FWHID_disableStreams()
*/
extern bool FWHID_getStreamEnables(FWMultiTouchDevicePtr fwdevice, FWBYTE *stream_mask);

/**
  This function uses getFeature/setFeature requests to specify whether the device transmits contact/path reports every image frame.  If no frames are skipped reports should arrive at 100-120Hz.
  @sa FWHID_setFlathandReset()
  @param fwdevice The device of interest
  @param frames2skip An int between 0 (transmit path data every frame) and 15 (only transmit every 16th frame).
  @return Whether the underlying HID Get/Set Feature I/O call were successful. NOTE:  Check for failure on unsupported streams or operating systems.
*/
extern bool FWHID_setPathFramesToSkip(FWMultiTouchDevicePtr fwdevice, int frames2skip);


/**
  This function uses getFeature/setFeature requests to specify whether flattening the hand on the surface should recalibrate device imaging (and reset the usb connection if repeated 5 times).  This feature is normally enabled on device power-up.
  @brief For enabling/disabling flathand reset gesture.
  @sa FWHID_setFlathandReset()
  @param fwdevice The device of interest
  @param enable_flathand_reset A boolean that enables flathand reset gesture if true, disables if false.
  @return Whether the underlying HID Get/Set Feature I/O call were successful. NOTE:  Check for failure on unsupported streams or operating systems.
*/
extern bool FWHID_setFlathandReset(FWMultiTouchDevicePtr fwdevice, bool enable_flathand_reset);


//print descriptions of USB device and surface dimensions
extern void FWHID_printUSBDeviceInfo(FWMultiTouchDevicePtr fwdevice,int nesting_level);
extern void FWHID_printImagingSurfaceInfo(FWMultiTouchDevicePtr fwdevice,int nesting_level);

//accessing device or imaging surface parameters

/**
@brief Gets the product name of a MultiTouch Device
@param fwdevice The device of interest.
@return A pointer to a null terminated string.
*/
extern char* FWHID_getProductName(FWMultiTouchDevicePtr fwdevice);
/**
@brief Gets the surface version of a MultiTouch Device

This value can used to determine which product the device is without using string compares.
@param fwdevice The device of interest.
@return The enumerated type ::FWSurfaceVersion
*/
extern int FWHID_getSurfaceVersion(FWMultiTouchDevicePtr fwdevice);

/**
@brief Gets the processor version of a MultiTouch Device

@param fwdevice The device of interest.
@return The enumerated type ::FWProcessorVersion
*/
extern int FWHID_getProcessorVersion(FWMultiTouchDevicePtr fwdevice);

/**
@brief Gets the keymatrix version of a MultiTouch Device

This value determines what key position layout (not key layout) is printed on the surface.
@note Only commercially available keymatrix values are documented by this SDK.
@param fwdevice The device of interest.
@return The enumerated type ::FWKeymatrixVersion
*/
extern int FWHID_getKeymatrixVersion(FWMultiTouchDevicePtr fwdevice);

/**
@brief Gets the Surface dimensions of a MultiTouch Device

@param fwdevice The device of interest.
@return The enumerated type ::FWSurfaceRectangle which contains the horizontal
coordinate of the left edge, the vertical coordinate of the bottom edge and the
width and height in centimeters
@sa FWSurfaceRectangle
*/
extern FWSurfaceRectangle FWHID_getSurfaceDimensions(FWMultiTouchDevicePtr fwdevice);



#ifdef __cplusplus
}
#endif

#endif // _FWHID_MultiTouchDevice.h

