// MultiLCDInteractiveConsoleCpp.cpp : Defines the entry point for the console application.
//

// #include "stdafx.h"
#define WIN32_LEAN_AND_MEAN
#include "pertelianlib.h"
#include <windows.h>
#include <iostream>
#include <conio.h>

#define MAX_DEVICES 5

int _tmain(int argc, char* argv[])
{
	CPertelianLib p1;

	DeviceName devices[MAX_DEVICES];
	
	//Detect all available devices
	int devicesFound = CPertelianLib::GetAvailableDevices(devices,MAX_DEVICES);

	//Print out all available devices
	std::cout<<"Please choose a device: "<<std::endl;

	for(int i=0;i<devicesFound;i++)
		std::cout<< (i+1) <<". "<<devices[i].name<<std::endl;
	
	int choice = 0;
	std::cin>>choice;

	if(choice > 0 && choice <= devicesFound) //if proper choice
	{
		if(p1.Initialize(4,20,true,&devices[choice - 1])) //open device by pathname
		{
			std::cout<<"Press any key to exit"<<std::endl;

			//streak a circle across 1 row
			int dotPosition = 1;
			while(!_kbhit())
			{
				p1.Write(" ",dotPosition++,1);
				p1.Write("o",dotPosition,1);

				if(dotPosition==p1.GetColumns())
				{
					p1.Write(" ",dotPosition,1);
					dotPosition = 1;
				}

				Sleep(200);
			}

			p1.Close(); //Close display
		}
	}

	return 0;
}

