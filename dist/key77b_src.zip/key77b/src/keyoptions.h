#ifndef GESTURE
#define GESTURE 0
#endif
#define KEYCAPTURE 0
#define KEYDISPLAY 0
