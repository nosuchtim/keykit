char * myre_compX(char *pat);
#ifdef EXTEND
#endif
#ifdef EXTEND
#endif
char *      myre_comp(char *pat);
#ifdef __STDC__
#else
#endif
int myre_exec(register char *lp);
#ifdef __STDC__
#else
#endif
void myre_modw(register char *s);
int myre_subs(register char *src, register char *dst);
#ifdef REGEXDEBUG
#endif
