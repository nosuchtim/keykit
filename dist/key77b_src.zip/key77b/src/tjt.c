#include <stdlib.h>
void
app_routine(short n)
{
	printf("app_routine n=%d\n",n);
}

main()
{
	__int64 v;
	v = 23000000000;
	printf("hi\n");
	app_routine(v);
}
