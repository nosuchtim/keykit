long mdep_milliclock(void);
void mdep_resetclock(void);
