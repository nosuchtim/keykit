void arrtomf(Htablep arr,char *fname);
