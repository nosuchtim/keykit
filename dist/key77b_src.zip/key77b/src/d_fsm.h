void midiparse(register int inbyte);
void realmess(int inbyte);
void chanmsg(int inbyte);
void sysmess(int inbyte);
void biggermess(Unchar **amessage,int *aMessleng);
