void gesture_init(HWND);
void gesture_end(void);
int gesture_nevents(void);
int gesture_clear(void);
char *gesture_devname(int);
void gesture_devinfo(int, const char **, double *, double *);
Datum gesture_get(void);
