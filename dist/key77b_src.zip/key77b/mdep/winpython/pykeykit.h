extern int keykit_init(int hwnd, int hinst);
extern int keykit_setcallback(PyObject* f);
extern int keykit_keyeval(char * s);
