/* This file is here as a placeholder, for cases when the clock support
/* is, for example, embedded in the MIDI support. */

int NoClOcK = 1;   /* eliminates complaints about null contents */
