#include <windows.h>
#include "key.h"
#if GESTURE == 0
void gesture_init(HWND hwnd) { }
void gesture_end(void) { }
int gesture_devices() { return 0; }
void gesture_devinfo(int n, const char **surface, double *width, double *height) { }
Datum gesture_get() { return Noval; }
int gesture_nevents() { return 0; }
int gesture_clear() { return 0; }
#else
#include "keydll.h"
#include "../fingerworks/FWHID_MultiTouchDevice.h"

void saveportevent(void);

#define kMAX_DEVICES 10
#define MAXGESTEV 64

typedef struct gesture_event {
	int device;
	FWHID_ContactFrame frame;
} gesture_event;
	
gesture_event gEvents[MAXGESTEV];
int gNevents = 0;
int gPosFirst = -1;
int gPosNextFree = 0;

struct gdevice_info {
	FWMultiTouchDevicePtr gDevice;
	double xoff;
	double yoff;
	double width_cm;
	double height_cm;
} gDeviceInfo[kMAX_DEVICES];

int gInitialized = 0;
int gTotalDevices = 0;
HWND gKhwnd;

Datum Str_device, Str_contacts, Str_frame;

/*
 *  What comes into this function is centimeters, and what
 *  comes out is something thats scaled and guaranteed to be
 *  between 0.0 and 1.0
 */
gdevice_normalize(double *xposp, double *yposp, int i)
{
	double xpos = *xposp;
        double ypos = *yposp;
	struct gdevice_info *gd = &gDeviceInfo[i];

	xpos += gd->xoff;
	ypos += gd->yoff;
	/*
	 * Sometimes the gesture pads report values which are < 0 or 
	 * greater than the width, so we adjust for this on a per-pad basis.
	 */
	if ( xpos < 0.0 ) {
		gd->xoff += (-xpos);
		xpos = 0.0;
	} else if ( xpos > gd->width_cm ) {
		gd->xoff += (gd->width_cm - xpos);
		xpos = gd->width_cm;
	}
	if ( ypos < 0.0 ) {
		gd->yoff += (-ypos);
		ypos = 0.0;
	} else if ( ypos > gd->height_cm ) {
		gd->yoff += (gd->height_cm - ypos);
		ypos = gd->height_cm;
	}
	*xposp = xpos/gd->width_cm;
	*yposp = ypos/gd->height_cm;
}

//This is called after every frame
void DeviceFrameCompleteCallback(FWMultiTouchDevicePtr fwdevice, void *targetData){
	int i=0;

	if ( *Debuggesture ) {
		keyerrfile("DeviceFrameComplete Now=%ld\n",*Now);
	}

	//Find which MultiTouch device this is
	while(fwdevice != gDeviceInfo[i].gDevice && i < gTotalDevices)
		i++;

	if ( *Debuggesture ) {
		keyerrfile("DeviceFrameComplete mid1\n");
	}

	if(i == gTotalDevices) {
		if ( *Debuggesture ) {
			keyerrfile("DeviceFrameComplete DEVICE NOT FOUND\n");
		}
		return; //Device not found in tracking list
	}

	if ( gPosFirst == gPosNextFree ) {
		if ( *Debuggesture ) {
			keyerrfile("(Too many gesture events)");
		}
	} else {
		if ( *Debuggesture ) {
			keyerrfile("DeviceFrameComplete mid2\n");
		}
		gEvents[gPosNextFree].device = i;
		FWHID_getContactFrame(gDeviceInfo[i].gDevice,&(gEvents[gPosNextFree].frame));
		// keyerrfile("Saving frame, pos=%d\n",gPosNextFree);
		/* Manage pointers to do a circular list using gDevice[] */
		if ( gPosFirst < 0 )
			gPosFirst = gPosNextFree;
		gPosNextFree++;
		if ( gPosNextFree >= MAXGESTEV )
			gPosNextFree = 0;
		gNevents++;
		if ( *Debuggesture ) {
			keyerrfile("DeviceFrameComplete calling saveportevent\n");
		}
		saveportevent();
		PostMessage (gKhwnd, WM_KEY_PORT, 0, 0) ;
	}
	if ( *Debuggesture ) {
		keyerrfile("DeviceFrameComplete end\n");
	}
}

//The Device Creation Callback is called for every FW device found in the system
void DeviceCreationCallback(FWMultiTouchDevicePtr fwdevice, void *targetData){
	if ( *Debuggesture ) {
		keyerrfile("DeviceCreationCallback Now=%ld\n",*Now);
	}
	if(gTotalDevices < kMAX_DEVICES){

		FWSurfaceRectangle r;

		FWHID_enableStreams(fwdevice,kFW_ContactPathStream);		

		r = FWHID_getSurfaceDimensions(fwdevice);
		gDeviceInfo[gTotalDevices].gDevice = fwdevice;
		gDeviceInfo[gTotalDevices].xoff = 0.0;
		gDeviceInfo[gTotalDevices].yoff = 0.0;
		gDeviceInfo[gTotalDevices].width_cm = r.width_cm;
		gDeviceInfo[gTotalDevices].height_cm = r.height_cm;

		FWHID_setContactFrameCallback(
			gDeviceInfo[gTotalDevices].gDevice,DeviceFrameCompleteCallback);
		gTotalDevices++;
	}
}

//Called everytime a FW device is removed.
//Note: If a device is plugged in all devices are removed and then rediscovered
void DeviceDisposalCallback(FWMultiTouchDevicePtr fwdevice, void *targetData)
{

	int i=0;

	if ( *Debuggesture ) {
		keyerrfile("DeviceDisposalCallback Now=%ld\n",*Now);
	}

	while(fwdevice != gDeviceInfo[i].gDevice && i < gTotalDevices)
		i++;

	if(i == gTotalDevices)
		return; //device removed was not found in devices

	FWHID_disableStreams(fwdevice,kFW_ContactPathStream);
	
	if(i+1 < kMAX_DEVICES)
		memmove(&(gDeviceInfo[i].gDevice),&(gDeviceInfo[i+1].gDevice),
			sizeof(FWMultiTouchDevicePtr)*(gTotalDevices-i+1));

	gTotalDevices--;
}

void
gesture_init(HWND hwnd)
{
	Str_device = strdatum(uniqstr("device"));
	Str_contacts = strdatum(uniqstr("contacts"));
	Str_frame = strdatum(uniqstr("frame"));

	gTotalDevices = 0;
	FWHID_setDeviceCreationCallback(DeviceCreationCallback);
	FWHID_setDeviceDisposalCallback(DeviceDisposalCallback);
	FWHID_registerMultiTouchDevices(hwnd);
	gInitialized = 1;
	gKhwnd = hwnd;

}

void
gesture_end(void)
{
	if ( gInitialized ) {
		gInitialized = 0;
		FWHID_releaseMultiTouchDevices();
	}
}

int
gesture_devices()
{
	return gTotalDevices;
}

void
gesture_devinfo(int n, const char **surface, double *width, double *height)
{
	FWMultiTouchDevicePtr gd;
	FWSurfaceVersion v;
	FWSurfaceRectangle r;

	if ( n >= gTotalDevices )
		return;
	gd = gDeviceInfo[n].gDevice;

	r = FWHID_getSurfaceDimensions(gd);

	// We normalize all the x and y values to a range of 0.0 to 1.0,
	// so the width and height we report is 1.0 rather than the real one.
	
	*width = 1.0;
	*height = 1.0;

	v = FWHID_getSurfaceVersion(gd);
	switch(v){
	case kFW_iGesturePad_Surface:
		*surface = "iGesturePad";
		break;
	default:
		*surface = "unknown";
		break;
	}
}

int
gesture_clear(void)
{
	gPosFirst = -1;
	gPosNextFree = 0;
	gNevents = 0;
	return 0;
}

int
gesture_nevents(void)
{
	return gNevents;
#ifdef OLDSTUFF
	if ( gPosFirst == gPosNextFree )
		return MAXGESTEV;
	else if ( gPosFirst < gPosNextFree )
		return gPosNextFree - gPosFirst;
	else
		return MAXGESTEV - gPosFirst + gPosNextFree;
#endif
}

char *
gesture_devname(int n)
{
	char *s;
	FWMultiTouchDevicePtr gd;

	if ( n >= gTotalDevices )
		return "InvalidDeviceNumber";
	gd = gDeviceInfo[n].gDevice;
	s = FWHID_getProductName(gd);
	if ( s == NULL )
		return "NullReturnFromGetProductName";
	return s;
}


Datum
gesture_get()
{
	if ( gPosFirst < 0 ) {
		// keyerrfile("gesture_get returning Noval\n");
		return Noval;
	} else {
		FWHID_ContactFrame *f;
		int dev;
		int ci;
		Datum d;
		Datum ad;

		f = &gEvents[gPosFirst].frame;
		dev = gEvents[gPosFirst].device;
		gPosFirst++;
		if ( gPosFirst >= MAXGESTEV ) {
			// Wrap around
			gPosFirst = 0;
		}
		if ( gPosFirst == gPosNextFree ) {
			// When no more events, reset
			gPosFirst = -1;
			gPosNextFree = 0;
		}
		gNevents--;

		d = newarrdatum(0,3);
		setarraydata(d.u.arr,
			Str_device,numdatum(dev));
		setarraydata(d.u.arr,
			Str_contacts,numdatum(f->contact_count));
		setarraydata(d.u.arr,
			Str_frame,numdatum(f->frame_no));

		for ( ci=0; ci<f->contact_count; ci++ ) {

			double xpos = f->contacts[ci].xpos;
			double ypos = f->contacts[ci].ypos;

			gdevice_normalize(&xpos,&ypos,dev);

			ad = newarrdatum(1,3);
			setarraydata(ad.u.arr,
				Str_x,dbldatum(xpos));
			setarraydata(ad.u.arr,
				Str_y,dbldatum(ypos));
			setarraydata(ad.u.arr,
				Str_finger,numdatum(f->contacts[ci].finger_id));
			setarraydata(ad.u.arr,
				Str_hand,numdatum(f->contacts[ci].hand_id));
			setarraydata(ad.u.arr,
				Str_xvel,dbldatum(f->contacts[ci].xvel));
			setarraydata(ad.u.arr,
				Str_yvel,dbldatum(f->contacts[ci].yvel));
			setarraydata(ad.u.arr,
				Str_proximity,dbldatum(f->contacts[ci].proximity));
			setarraydata(ad.u.arr,
				Str_orientation,dbldatum(f->contacts[ci].orientation));
			setarraydata(ad.u.arr,
				Str_eccentricity,dbldatum(f->contacts[ci].eccentricity));

			setarraydata(d.u.arr,
				numdatum(ci),ad);
		}
		// keyerrfile("gesture_get returning array, gPos is now %d\n",gPosFirst);
		return d;
	}
}
#endif
