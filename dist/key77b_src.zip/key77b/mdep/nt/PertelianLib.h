#include <vector>

[module(dll, name="PertelianLib", version="1.0")] 
/// <summary>
///  C++ Pertelian Library
///  Version 1.1 01/19/08
///  This class is exported from the PertelianLib.dll
///  Provides operations on the Pertelian
/// </summary>

struct DeviceName
{
	char name[128];
};

class __declspec(dllimport) CPertelianLib {
class HIDDevice;
HIDDevice *m_pPertelian;
	
public:
    /// <summary>
    /// Default constructor
    /// </summary>
	CPertelianLib(void);
	~CPertelianLib();

	__declspec(deprecated("COM Port usage deprecated.  Use Initialize() instead"))
	bool Initialize(int COMPort);

	__declspec(deprecated("COM Port usage deprecated.  Use Initialize() instead"))
	bool Initialize(int COMPort,int Baud, int Rows, int Columns, bool DefaultBacklight);

    /// <summary>
    /// Initialize function initializes the LCD for operation.
	/// </summary>
    /// <returns>Returns true on successful initialization. Otherwise, false.</returns>
	/// <example>
	/// <code>
	/// CPertelianLib pertelianObject = new CPertelianLib();
	/// //initialize with 4 rows, 20 columns, and no backlight
	/// pertelianObject.Initialize();
	/// </code>
	/// </example>
	bool Initialize();

    /// <summary>
    /// Initialize function initializes the LCD for operation.
	/// </summary>
	/// <param name="Rows">Number of rows to initialize display with.</param>
	/// <param name="Columns">Number of columns to initialize display with.</param>
	/// <param name="DefaultBacklight">Sets backlight on or off on initialization</param>
    /// <returns>Returns true on successful initialization. Otherwise, false.</returns>
	/// <example>
	/// <code>
	/// CPertelianLib pertelianObject = new CPertelianLib();
	/// //initialize with 4 rows, 20 columns, and no backlight
	/// pertelianObject.Initialize(4,20,false);
	/// </code>
	/// </example>
	bool Initialize(int Rows, int Columns, bool DefaultBacklight);

    /// <summary>
    /// Gets a value indicating whether the LCD Com Port is open.
    /// </summary>
    /// <value><c>true</c> if the Com Port is open; otherwise, <c>false</c>.</value>
    bool IsOpen();

    /// <summary>
    /// Write string operation
	/// </summary>
    /// <param name="Data">Data to write.  </param>
	/// <param name="Column">Column to begin write.  First column is 1.</param>
	/// <param name="Row">Row to begin write.  First row is 1.</param>
	/// <example>
	/// <code>
	/// CPertelianLib pertelianObject = new CPertelianLib();
	///
	/// pertelianObject.Initialize(3);
	///
	/// //write "Data" at column 1, row 5
	/// pertelianObject.Write("Data",1,5);
	///
	/// </code>
	/// </example>
	void Write(const char* Data,int Column, int Row);

    /// <summary>
    /// Write character operation
	/// </summary>
    /// <param name="Data">Data to write. </param>
	/// <param name="Column">Column to begin write.  First column is 1.</param>
	/// <param name="Row">Row to begin write.  First row is 1.</param>
	/// <example>
	/// <code>
	/// CPertelianLib pertelianObject = new CPertelianLib();
	///
	/// pertelianObject.Initialize(3);
	///
	/// //write ASCII 126 "->" at column 1, row 5
	/// pertelianObject.Write((char)126,1,5);
	/// </code>
	/// </example>
	void Write(unsigned char Data,int Column, int Row);

	/// <summary>
    /// Write data operation
	/// </summary>
    /// <param name="Data">Data to write. </param>
	/// <example>
	/// <code>
	/// CPertelianLib pertelianObject = new CPertelianLib();
	///
	/// pertelianObject.Initialize(3);
	///
	/// //write command 0xFE
	/// pertelianObject.Write((char)0xFE);
	/// </code>
	/// </example>
	void Write(unsigned char Data);

    /// <summary>
    /// Write a custom character
    /// </summary>
    /// <param name="Address">The memory address location</param>
    /// <param name="Column">Column to begin write.  First column is 1.</param>
    /// <param name="Row">Row to begin write.  First row is 1.</param>
    /// <example>
    /// <code>
    /// CPertelianLib pertelianObject = new CPertelianLib();
    /// pertelianObject.Initialize(3);
    /// //load a square character to memory address 1
    /// char[] square={0x1f,0x1f,0x1f,0x1f,0x1f,0x1f,0x1f,0x00};
    /// pertelianObject.LoadCustomChar(1, stop);
    /// //write custom character 1 at column 2, row 1
    /// pertelianObject.WriteCustomChar(1,2,1);
    /// </code>
    /// </example>
    void WriteCustomChar(int Address, int Column, int Row);

    /// <summary>
    /// Clears the LCD
    /// </summary>
	void Clear();

    /// <summary>
    /// Gets a value indicating backlight status
    /// </summary>
    /// <returns><c>true</c> if backlight is on; otherwise, <c>false</c>.</returns>
	bool GetBacklight();

    /// <summary>
    /// Sets a value indicating backlight status
    /// </summary>
	void SetBacklight(bool Status);

    /// <summary>
    /// Gets the number of columns.
    /// </summary>
    /// <value>The columns.</value>
	int GetColumns();

    /// <summary>
    /// Gets the number of rows.
    /// </summary>
    /// <value>The rows.</value>
	int GetRows();

    /// <summary>
    /// Sets a value indicating backlight status
    /// </summary>
	void ToggleBacklight();

    /// <summary>
    /// Loads a custom character
    /// </summary>
    /// <param name="CGRAMAddress">The CGRAM address.</param>
    /// <param name="CharacterPattern">The character pattern.</param>
    /// <example>
    /// <code>
    /// CPertelianLib pertelianObject = new CPertelianLib();
    /// pertelianObject.Initialize(3);
    /// //load a square character to memory address 1
    /// byte[] square={0x1f,0x1f,0x1f,0x1f,0x1f,0x1f,0x1f,0x00};
    /// pertelianObject.LoadCustomChar(1, square);
    /// </code>
    /// </example>
	void LoadCustomChar(int CGRAMAddress, char CharacterPattern[]);

    /// <summary>
    /// Close the LCD
    /// </summary>
	void Close();

    /// <summary>
    /// Gets a list of available USB device paths 
    /// </summary>
    /// <param name="List">Vector of strings which will contain all detected USB device paths</param>
    /// <example>
    /// <code>
	/// std::vector<std::string> deviceList;
	/// CPertelianLib::GetAvailableDevices(deviceList);
    /// </code>
    /// </example>
	static void GetAvailableDevices(std::vector<std::string>& List);

	static int GetAvailableDevices(DeviceName* pDevices, int maxDevices);

    /// <summary>
    /// Initialize function initializes the LCD for operation.
	/// </summary>
	/// <param name="Rows">Number of rows to initialize display with.</param>
	/// <param name="Columns">Number of columns to initialize display with.</param>
	/// <param name="DefaultBacklight">Sets backlight on or off on initialization</param>
	/// <param name="UsbDevicePath">Full USB device path name of LCD device</param>
    /// <returns>Returns true on successful initialization. Otherwise, false.</returns>
	/// <example>
	/// <code>
	/// CPertelianLib pertelianObject = new CPertelianLib();
	/// //initialize with 4 rows, 20 columns, and no backlight with USB path name
	/// pertelianObject.Initialize(4,20,false,"\\?\ftdibus#vid_0403+pid_6001+5&106ad93b&0&2#0000#{4d36e978-e325-11ce-bfc1-08002be10318}");
	/// </code>
	/// </example>
	bool Initialize(int Rows, int Columns, bool DefaultBacklight, std::string UsbDevicePath);

	bool Initialize(int Rows, int Columns, bool DefaultBacklight, DeviceName* device);
};


