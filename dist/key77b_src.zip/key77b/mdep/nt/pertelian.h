void pertelian_open();
int pertelian_isopen(int pnum);
void pertelian_backlight(int pnum, int t);
void pertelian_clear(int pnum);
void pertelian_write(int pnum, char *s, int col, int row);
void pertelian_close();
