#define WIN32_LEAN_AND_MEAN
#include <stdio.h>
#include <tchar.h>
#include "pertelianlib.h"
#include <windows.h>

extern "C" {

#if PERTELIAN == 0
void pertelian_write(int pnum, char *msg) { }
#else

#define NLCDS 4
CPertelianLib lcd[NLCDS];
BOOL lcd_isopen[NLCDS];

void
pertelian_open()
{
	for ( int n=0; n<NLCDS; n++ ) {
		lcd_isopen[n] = lcd[n].Initialize();
	}
	// lcd_isopen[0] = lcd[0].Initialize();
	// lcd_isopen[1] = 0;
}

void
pertelian_clear(int pnum)
{
	if ( ! ( pnum >= 0 && pnum < NLCDS && lcd_isopen[pnum] ) ) {
		return;
	}
	lcd[pnum].Clear();
}

int
pertelian_isopen(int pnum)
{
	if ( ! ( pnum >= 0 && pnum < NLCDS && lcd_isopen[pnum] ) ) {
		return 0;
	}
	return lcd_isopen[pnum];
}

void
pertelian_backlight(int pnum, int t)
{
	if ( ! ( pnum >= 0 && pnum < NLCDS && lcd_isopen[pnum] ) ) {
		return;
	}
	lcd[pnum].SetBacklight(t!=0);
}

void
pertelian_write(int pnum, char *s, int col, int row)
{
	char msg[32];

	if ( ! ( pnum >= 0 && pnum < NLCDS && lcd_isopen[pnum] ) ) {
		return;
	}

	if ( col < 0 || col >= 20 || row < 0 || row >= 4 ) {
		lcd[pnum].Write("write: bad row/col", 1, 1);
		return;
	}

	// Make sure we don't try to write past the 20th column.
	// DON'T modify the contents of s!
	strncpy(msg,s,20);
	msg[20-col] = '\0';

	// NOTE: column and row values in Pertelian library are 1-based

	lcd[pnum].Write(msg, col+1, row+1);
}

void
pertelian_close()
{
	// lcd[0].Close();
	for ( int n=0; n<NLCDS; n++ ) {
		if ( lcd_isopen[n] ) {
			lcd[n].Close();
		}
	}
}

#endif

}
