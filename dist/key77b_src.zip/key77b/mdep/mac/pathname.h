void PathNameFromDirID(long dirID, short vRefNum, StringPtr fullPathName);
void pstrcat(StringPtr dst, StringPtr src);
void pstrinsert(StringPtr dst, StringPtr src);
void PathNameFromWD(long vRefNum, StringPtr pathName);