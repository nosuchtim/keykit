KeyKit 8.8 for Windows (x64)

Extract the entire key folder, then run bin\key.exe. Keep its DLLs alongside it.
The console interpreter is bin\lowkey.exe. To rebuild the library index after
editing it, run bin\keylib.exe with lib as the working directory.

WinMM is the default MIDI backend. Set KEYKIT_MIDI_API=wms before starting
KeyKit to request Windows MIDI Services. See README.windows for details.
Documentation is in doc, library/tools in lib, and sample music in music.
Licenses and WMS preview/runtime information are in LICENSE.txt and rtmidi.

This WinMM edition supports Windows 10 or later and excludes the Windows MIDI
Services preview API. Use the default WinMM backend. On supported Windows 11
systems, use key88_win.zip for the bundled WMS API.